package metabuilder.diagram.nodes;

public abstract class DataTypeNode extends TypeNode {

}
