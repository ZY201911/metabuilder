package metabuilder.diagram.nodes;

public final class PrimitiveTypeNode extends DataTypeNode {

}
